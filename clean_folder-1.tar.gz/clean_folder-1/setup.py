from setuptools import setup, find_namespace_packages

setup(
    name='clean_folder',
    version='1',
    description='Clean folder',
    url='https://github.com/Vel-Vladimir/Python---HW-6/blob/main/sort.py',
    author='Velikiy Vladymyr',
    author_email='vel.vlad.optimus@gmail.com',
    license='MIT',
    packages=find_namespace_packages(),
    entry_points={'console_scripts': ['clean-folder = clean_folder.clean:main']}
)